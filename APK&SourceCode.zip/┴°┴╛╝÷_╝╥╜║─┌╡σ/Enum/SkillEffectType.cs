﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Enum
{
    public enum SkillEffectType
    {
        None,
        Target,
        HitBox,
        KnockBack,
        Projectile,
        Channeling,
        TargetTracking,
        Summon,
        Dash,
    }
}