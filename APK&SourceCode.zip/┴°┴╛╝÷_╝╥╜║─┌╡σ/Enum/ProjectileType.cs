﻿namespace Enum
{ 
    public enum ProjectileType
    {
        None,
        FireBall_Large,
    }
}