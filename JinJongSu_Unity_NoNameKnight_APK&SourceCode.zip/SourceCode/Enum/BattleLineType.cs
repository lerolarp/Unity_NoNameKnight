﻿namespace Enum
{
    public enum BattleLineType
    {
        Front = 0,
        Middle = 1,
        Back = 2,
        None = 3
    }
}
