﻿using UnityEngine;
public class Component : MonoBehaviour
{
}